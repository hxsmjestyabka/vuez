
# Glover Website Update - 1.2.0

Backend - 
For the parcel to work in the new website version, you need to update controller file in your Backend.

The file - PackageOrderController.php - is located in the backend folder in this update, just move the controller file to the same patch on your backend project folders 

Path: app/Http/Controllers/API/


